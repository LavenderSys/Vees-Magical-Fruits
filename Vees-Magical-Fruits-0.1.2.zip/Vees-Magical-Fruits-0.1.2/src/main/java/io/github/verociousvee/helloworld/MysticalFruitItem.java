package io.github.verociousvee.helloworld;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class MysticalFruitItem extends Item {
    public MysticalFruitItem(Settings settings) {
        super(settings);
    }
    public boolean hasGlint(ItemStack stack) {
        return true;
    }
}
