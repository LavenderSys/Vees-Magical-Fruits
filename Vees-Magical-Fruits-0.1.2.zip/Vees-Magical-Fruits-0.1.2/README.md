# Vee's Magical Fruits

## Info

This mod currently has three items:
 * Strawberries, which give you jump
 * Bananas, which make you invisible 
 * Bloody Banana Smoothy, which is a shapeless recipe that uses ice, a strawberry, a banana, and a glass bottle. 
    * Alongside increasing the levels of the afformentioned effects, this changes the time of the effects from 35 seconds to a minute, and gives the user speed. I hope you enjoy.

Also, this is my first ever attempt at making a mod, or coding java in general for that matter, so huge thanks to Caroline (@halotroop2288) for all of her help and patience along the way, as well as the Fabric Discord server for their help on this.

![Fabric API Required](https://i.imgur.com/Ol1Tcf8.png)
